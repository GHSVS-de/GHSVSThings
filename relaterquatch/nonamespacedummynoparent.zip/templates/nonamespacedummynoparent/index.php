<?php
defined('_JEXEC') or die;

require_once __DIR__ . '/helpers/TemplateHelper.php';

?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<jdoc:include type="head" />
</head>
<body>
    Test for namespace example with no namespace and no parent<br>
    <div id="testoutput"><?php echo TemplateHelper::Test(); ?></div>
    <jdoc:include type="component" />
</body>
</html>
