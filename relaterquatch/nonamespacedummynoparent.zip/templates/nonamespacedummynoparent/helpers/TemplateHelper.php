<?php

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

abstract class TemplateHelper
{
  public static function Test() {
    return 'Test no namespace no parent';
  }
}
